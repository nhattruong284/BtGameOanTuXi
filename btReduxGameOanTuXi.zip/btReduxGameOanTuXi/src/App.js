import logo from './logo.svg';
import './App.css';
import BTGameOanTuXi from './BTRedux/BTGameOanTuXi/BTGameOanTuXi';

function App() {
  return (
    <div className="App">
      <BTGameOanTuXi />
    </div>
  );
}

export default App;
